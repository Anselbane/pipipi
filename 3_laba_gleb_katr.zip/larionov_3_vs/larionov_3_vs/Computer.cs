﻿namespace larionov_3_vs
{
public class Computer
{
    public int ComputerID { get; set; }
    public string Name { get; set; }
    public string Location { get; set; }
}

}
