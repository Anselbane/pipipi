﻿namespace larionov_3_vs
{
    public class Booking
    {
        public int BookingID { get; set; }
        public int ComputerID { get; set; }
        public int UserID { get; set; }
        public DateTime BookingDate { get; set; }
        public int Duration { get; set; }
    }
}
